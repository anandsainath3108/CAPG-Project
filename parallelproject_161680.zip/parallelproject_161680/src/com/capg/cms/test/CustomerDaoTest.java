package com.capg.cms.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;

import com.capg.cms.dao.CustomerDaoImpl;
import com.capg.cms.entity.Account;
import com.capg.cms.entity.Transaction;
import com.capg.cms.exception.AccountException;

class CustomerDaoTest {

		CustomerDaoImpl dao = null;
	    Account account1,account2 = null;
	    Transaction transaction,transaction1 = null;
			@Test
			public void testCreateAccount() throws AccountException {
		       
				dao = new CustomerDaoImpl();
				account1 = new Account();
				account1.setAccountNo(123456L);
		        account1.setName("djMaMa");
		        account1.setIdProofNo("7894561230");
		        account1.setMobileNo("8885122209");
		        account1.setEmailId("mama@dj.com");
		        account1.setAddr("Hyderabad-Deccan");
		        account1.setUsername("dj_mama@1");
		        account1.setPassword("ansquared1");
		        account1.setAge(122);
		        account1.setBalance(100000.0);

		        boolean b1=dao.addCustomer(account1);
		        assertTrue("True", b1);
		        
		        account2 = new Account();
				account2.setAccountNo(234567L);
		        account2.setName("djMaMa2");
		        account2.setIdProofNo("9874561230");
		        account2.setMobileNo("8886222210");
		        account2.setEmailId("mama2@dj.com");
		        account2.setAddr("Mumbai-Bkc");
		        account2.setUsername("dj_mama@2");
		        account2.setPassword("ansquared2");
		        account2.setAge(121);
		        account2.setBalance(200000.0);
		        
		        boolean b2=dao.addCustomer(account2);
		        assertTrue("True", b2);
			}


			@Test
			public void testDisplayAccount() throws AccountException {
		        dao = new CustomerDaoImpl();
		        Account d1 = dao.displayAccount(123456L);
		        Double balance = d1.getBalance();
		        assertEquals(100000.0, balance ,0);
			} 
		 
			
			@Test
			public void testDeposit() throws AccountException {
		       
			}

			
			@Test
			public void testWithdraw() throws AccountException {
		        
			}
			
			
			@Test
			public void testFundTransfer() throws AccountException {
		        
			}
			
			
			@Test
			public void testAddTransaction() throws AccountException {
		        dao = new CustomerDaoImpl();
		       LocalDate date = LocalDate.now();
		       transaction.setUtrNo(12345678L);
		     /*transaction.setAccountNoCr(123456L);
		       transaction.setAccountNoDr(234567L);
		       transaction.setTransferAmt(10000.0);
		       transaction.setBalance(100000.0);
		       transaction.setDate(date);
		       transaction.setTransactiontype("Cr.");*/
		       dao.addTransaction(transaction);
			}
	}


